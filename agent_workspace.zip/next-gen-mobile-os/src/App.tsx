import { useState, useEffect, useRef } from 'react'
import { MobileOS } from './components/MobileOS'
import { GestureProvider } from './components/GestureProvider'
import { ThemeProvider } from './components/ThemeProvider'
import './App.css'

function App() {
  return (
    <ThemeProvider>
      <GestureProvider>
        <div className="w-full h-screen overflow-hidden bg-black">
          <MobileOS />
        </div>
      </GestureProvider>
    </ThemeProvider>
  )
}

export default App
