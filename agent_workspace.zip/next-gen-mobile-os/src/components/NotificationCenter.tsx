import React, { useState, useEffect, useRef } from 'react'
import { useGesture } from './GestureProvider'
import { useTheme } from './ThemeProvider'

interface NotificationCenterProps {
  visible: boolean
  onClose: () => void
}

interface Notification {
  id: string
  app: string
  title: string
  content: string
  timestamp: Date
  icon: string
  priority: 'high' | 'normal' | 'low'
  category: string
}

const SAMPLE_NOTIFICATIONS: Notification[] = [
  {
    id: '1',
    app: 'Messages',
    title: 'New Message',
    content: 'Hey! Check out this revolutionary OS interface 🚀',
    timestamp: new Date(Date.now() - 120000),
    icon: '💬',
    priority: 'high',
    category: 'communication'
  },
  {
    id: '2',
    app: 'Weather',
    title: 'Weather Update',
    content: 'Partly cloudy, 22°C. Perfect day for UI design!',
    timestamp: new Date(Date.now() - 300000),
    icon: '🌤️',
    priority: 'normal',
    category: 'information'
  },
  {
    id: '3',
    app: 'Calendar',
    title: 'Upcoming Event',
    content: 'Tech Conference - Next-Gen Mobile Interfaces',
    timestamp: new Date(Date.now() - 600000),
    icon: '📅',
    priority: 'normal',
    category: 'productivity'
  },
  {
    id: '4',
    app: 'System',
    title: 'OS Update Available',
    content: 'New features and improvements ready to install',
    timestamp: new Date(Date.now() - 900000),
    icon: '⚙️',
    priority: 'low',
    category: 'system'
  }
]

export const NotificationCenter: React.FC<NotificationCenterProps> = ({ visible, onClose }) => {
  const [notifications, setNotifications] = useState(SAMPLE_NOTIFICATIONS)
  const [pullProgress, setPullProgress] = useState(0)
  
  const notificationRef = useRef<HTMLDivElement>(null)
  const { registerGesture, hapticFeedback } = useGesture()
  const { resolvedTheme } = useTheme()

  useEffect(() => {
    if (!notificationRef.current || !visible) return

    const element = notificationRef.current

    // Register swipe up to close
    const cleanup = registerGesture(element, {
      type: 'swipe-up',
      threshold: 100,
      callback: () => {
        hapticFeedback('light')
        onClose()
      }
    })

    return cleanup
  }, [registerGesture, visible, onClose, hapticFeedback])

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
    hapticFeedback('light')
  }

  const clearAllNotifications = () => {
    setNotifications([])
    hapticFeedback('medium')
  }

  const formatTimestamp = (timestamp: Date) => {
    const now = new Date()
    const diff = now.getTime() - timestamp.getTime()
    const minutes = Math.floor(diff / 60000)
    
    if (minutes < 1) return 'now'
    if (minutes < 60) return `${minutes}m ago`
    
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours}h ago`
    
    const days = Math.floor(hours / 24)
    return `${days}d ago`
  }

  const NotificationCard: React.FC<{ notification: Notification; index: number }> = ({ notification, index }) => {
    const [isSwipingOut, setIsSwipingOut] = useState(false)

    return (
      <div
        className={`
          relative mb-3 transform transition-all duration-300 ease-out
          ${isSwipingOut ? 'translate-x-full opacity-0' : 'translate-x-0 opacity-100'}
        `}
        style={{
          animation: `slide-down 0.4s ease-out ${index * 0.1}s both`
        }}
      >
        <div className={`
          glass rounded-2xl p-4 
          ${resolvedTheme === 'dark' ? 'glass-dark' : 'glass'}
          transition-all duration-300 hover:scale-[1.02]
        `}>
          <div className="flex items-start space-x-3">
            {/* App Icon */}
            <div className={`
              w-10 h-10 rounded-xl flex items-center justify-center text-lg
              ${notification.priority === 'high' 
                ? 'bg-red-500/20 text-red-400' 
                : notification.priority === 'normal'
                ? 'bg-blue-500/20 text-blue-400'
                : 'bg-gray-500/20 text-gray-400'
              }
            `}>
              {notification.icon}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className={`
                  text-sm font-medium
                  ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
                `}>
                  {notification.app}
                </span>
                <span className={`
                  text-xs
                  ${resolvedTheme === 'dark' ? 'text-gray-400' : 'text-gray-500'}
                `}>
                  {formatTimestamp(notification.timestamp)}
                </span>
              </div>
              
              <div className={`
                font-medium text-sm mb-1
                ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
              `}>
                {notification.title}
              </div>
              
              <div className={`
                text-sm leading-tight
                ${resolvedTheme === 'dark' ? 'text-gray-300' : 'text-gray-600'}
              `}>
                {notification.content}
              </div>
            </div>

            {/* Actions */}
            <button
              className={`
                w-8 h-8 rounded-full flex items-center justify-center text-xs
                ${resolvedTheme === 'dark' 
                  ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' 
                  : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                }
                transition-colors duration-200
              `}
              onClick={() => {
                setIsSwipingOut(true)
                setTimeout(() => clearNotification(notification.id), 300)
              }}
            >
              ×
            </button>
          </div>
        </div>
      </div>
    )
  }

  if (!visible) return null

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
        style={{ animation: 'fade-in-up 0.3s ease-out' }}
      />

      {/* Notification Panel */}
      <div
        ref={notificationRef}
        className={`
          absolute top-0 left-0 right-0 max-h-screen overflow-y-auto
          ${resolvedTheme === 'dark' 
            ? 'bg-black/80' 
            : 'bg-white/80'
          }
          backdrop-blur-xl border-b border-white/10
        `}
        style={{ 
          animation: 'slide-down 0.4s ease-out',
          paddingTop: '60px'
        }}
      >
        {/* Header */}
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className={`
              text-xl font-semibold
              ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
            `}>
              Notifications
            </h2>
            
            {notifications.length > 0 && (
              <button
                className={`
                  px-3 py-1 rounded-full text-sm font-medium
                  ${resolvedTheme === 'dark' 
                    ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' 
                    : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                  }
                  transition-colors duration-200
                `}
                onClick={clearAllNotifications}
              >
                Clear All
              </button>
            )}
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-4 gap-3 mb-6">
            {[
              { icon: '🔆', label: 'Brightness', action: () => {} },
              { icon: '📶', label: 'WiFi', action: () => {} },
              { icon: '🔵', label: 'Bluetooth', action: () => {} },
              { icon: '✈️', label: 'Airplane', action: () => {} }
            ].map((action, index) => (
              <button
                key={action.label}
                className={`
                  glass rounded-2xl p-3 flex flex-col items-center space-y-1
                  ${resolvedTheme === 'dark' ? 'glass-dark' : 'glass'}
                  transition-all duration-200 hover:scale-105
                `}
                style={{
                  animation: `bounce-in 0.5s ease-out ${index * 0.1}s both`
                }}
                onClick={action.action}
              >
                <div className="text-xl">{action.icon}</div>
                <div className={`
                  text-xs font-medium
                  ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
                `}>
                  {action.label}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Notifications List */}
        <div className="px-6 pb-6">
          {notifications.length === 0 ? (
            <div className={`
              text-center py-12
              ${resolvedTheme === 'dark' ? 'text-gray-400' : 'text-gray-500'}
            `}>
              <div className="text-4xl mb-4">📭</div>
              <div className="font-medium">No Notifications</div>
              <div className="text-sm mt-1">You're all caught up!</div>
            </div>
          ) : (
            <div>
              {notifications.map((notification, index) => (
                <NotificationCard 
                  key={notification.id} 
                  notification={notification} 
                  index={index}
                />
              ))}
            </div>
          )}
        </div>

        {/* Pull Indicator */}
        <div className="flex justify-center pb-4">
          <div className={`
            w-8 h-1 rounded-full
            ${resolvedTheme === 'dark' ? 'bg-white/40' : 'bg-black/40'}
          `} />
        </div>
      </div>
    </div>
  )
}
