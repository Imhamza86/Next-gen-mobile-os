import React, { useState, useEffect, useRef } from 'react'
import { useGesture } from './GestureProvider'
import { useTheme } from './ThemeProvider'

interface App {
  id: string
  name: string
  icon: string
  category: string
  color: string
}

interface HomescreenProps {
  onAppLaunch: (appId: string) => void
}

const APPS: App[] = [
  { id: 'messages', name: 'Messages', icon: '💬', category: 'communication', color: 'from-green-400 to-green-600' },
  { id: 'phone', name: 'Phone', icon: '📞', category: 'communication', color: 'from-blue-400 to-blue-600' },
  { id: 'camera', name: 'Camera', icon: '📷', category: 'media', color: 'from-gray-400 to-gray-600' },
  { id: 'photos', name: 'Photos', icon: '🖼️', category: 'media', color: 'from-yellow-400 to-orange-500' },
  { id: 'music', name: 'Music', icon: '🎵', category: 'media', color: 'from-pink-400 to-red-500' },
  { id: 'settings', name: 'Settings', icon: '⚙️', category: 'system', color: 'from-gray-500 to-gray-700' },
  { id: 'calculator', name: 'Calculator', icon: '🧮', category: 'utilities', color: 'from-indigo-400 to-purple-600' },
  { id: 'weather', name: 'Weather', icon: '🌤️', category: 'utilities', color: 'from-blue-300 to-sky-500' },
  { id: 'notes', name: 'Notes', icon: '📝', category: 'productivity', color: 'from-yellow-300 to-amber-400' },
  { id: 'browser', name: 'Browser', icon: '🌐', category: 'internet', color: 'from-cyan-400 to-teal-500' },
  { id: 'maps', name: 'Maps', icon: '🗺️', category: 'navigation', color: 'from-emerald-400 to-green-500' },
  { id: 'clock', name: 'Clock', icon: '⏰', category: 'utilities', color: 'from-slate-400 to-slate-600' }
]

export const Homescreen: React.FC<HomescreenProps> = ({ onAppLaunch }) => {
  const [apps, setApps] = useState(APPS)
  const [editMode, setEditMode] = useState(false)
  const [currentPage, setCurrentPage] = useState(0)
  const [draggedApp, setDraggedApp] = useState<string | null>(null)
  
  const homescreenRef = useRef<HTMLDivElement>(null)
  const { registerGesture, hapticFeedback } = useGesture()
  const { resolvedTheme } = useTheme()

  const appsPerPage = 20
  const totalPages = Math.ceil(apps.length / appsPerPage)

  useEffect(() => {
    if (!homescreenRef.current) return

    const element = homescreenRef.current

    // Register long press for edit mode
    const cleanup = registerGesture(element, {
      type: 'long-press',
      duration: 800,
      callback: () => {
        if (!editMode) {
          setEditMode(true)
          hapticFeedback('heavy')
        }
      }
    })

    return cleanup
  }, [registerGesture, editMode, hapticFeedback])

  const getCurrentPageApps = () => {
    const startIndex = currentPage * appsPerPage
    return apps.slice(startIndex, startIndex + appsPerPage)
  }

  const handleAppTap = (appId: string) => {
    if (editMode) {
      setEditMode(false)
      return
    }
    
    hapticFeedback('light')
    onAppLaunch(appId)
  }

  const handleAppLongPress = (appId: string) => {
    if (!editMode) {
      setEditMode(true)
      hapticFeedback('heavy')
    }
  }

  const AppIcon: React.FC<{ app: App; index: number }> = ({ app, index }) => {
    const [isPressed, setIsPressed] = useState(false)

    return (
      <div
        className={`
          relative flex flex-col items-center space-y-2 p-2
          transition-all duration-200 ease-out cursor-pointer
          ${editMode ? 'animate-wiggle' : ''}
          ${isPressed ? 'scale-95' : 'scale-100'}
        `}
        style={{
          animation: editMode ? `wiggle 0.8s ease-in-out infinite ${index * 0.1}s` : undefined
        }}
        onTouchStart={() => setIsPressed(true)}
        onTouchEnd={() => setIsPressed(false)}
        onClick={() => handleAppTap(app.id)}
      >
        {/* App Icon */}
        <div 
          className={`
            w-16 h-16 rounded-2xl flex items-center justify-center text-2xl
            bg-gradient-to-br ${app.color} shadow-lg
            transition-all duration-300 ease-out
            ${isPressed ? 'shadow-xl scale-95' : 'shadow-lg'}
            ${editMode ? 'shadow-2xl' : ''}
          `}
          style={{
            animation: `fade-in-up 0.4s ease-out ${index * 0.05}s both`
          }}
        >
          {app.icon}
          
          {/* Delete button in edit mode */}
          {editMode && (
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white text-xs shadow-lg">
              ×
            </div>
          )}
        </div>

        {/* App Name */}
        <div className={`
          text-xs font-medium text-center leading-tight max-w-16
          ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
        `}>
          {app.name}
        </div>
      </div>
    )
  }

  return (
    <div 
      ref={homescreenRef}
      className={`
        relative w-full h-full overflow-hidden
        ${resolvedTheme === 'dark' 
          ? 'bg-gradient-to-br from-gray-900 via-slate-900 to-black' 
          : 'bg-gradient-to-br from-blue-50 via-indigo-50 to-white'
        }
      `}
    >
      {/* Dynamic Wallpaper */}
      <div className="absolute inset-0 w-full h-full opacity-30">
        {/* Animated background elements */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className={`
              absolute rounded-full opacity-20
              ${resolvedTheme === 'dark' ? 'bg-white' : 'bg-black'}
            `}
            style={{
              width: `${20 + Math.random() * 40}px`,
              height: `${20 + Math.random() * 40}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${4 + Math.random() * 6}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 3}s`
            }}
          />
        ))}
      </div>

      {/* App Grid */}
      <div className="relative z-10 pt-16 pb-24 px-6 h-full">
        <div className="grid grid-cols-4 gap-4 h-full content-start">
          {getCurrentPageApps().map((app, index) => (
            <AppIcon key={app.id} app={app} index={index} />
          ))}
        </div>
      </div>

      {/* Page Indicators */}
      {totalPages > 1 && (
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {[...Array(totalPages)].map((_, index) => (
            <div
              key={index}
              className={`
                w-2 h-2 rounded-full transition-all duration-300
                ${index === currentPage 
                  ? 'bg-white scale-125' 
                  : resolvedTheme === 'dark' 
                    ? 'bg-white/40' 
                    : 'bg-black/40'
                }
              `}
            />
          ))}
        </div>
      )}

      {/* Dock */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2">
        <div className={`
          glass rounded-3xl px-4 py-3 flex space-x-4
          ${resolvedTheme === 'dark' ? 'glass-dark' : 'glass'}
        `}>
          {['phone', 'messages', 'camera', 'browser'].map((appId, index) => {
            const app = apps.find(a => a.id === appId)
            if (!app) return null
            
            return (
              <div
                key={appId}
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl bg-gradient-to-br from-gray-400 to-gray-600 shadow-lg cursor-pointer transition-transform duration-200 hover:scale-110"
                onClick={() => handleAppTap(appId)}
                style={{
                  animation: `bounce-in 0.5s ease-out ${index * 0.1}s both`
                }}
              >
                {app.icon}
              </div>
            )
          })}
        </div>
      </div>

      {/* Edit Mode Overlay */}
      {editMode && (
        <div className="absolute inset-0 bg-black/20 z-50 flex items-end justify-center pb-6">
          <button
            className="px-6 py-3 bg-blue-500 text-white rounded-full font-medium shadow-lg"
            onClick={() => setEditMode(false)}
          >
            Done
          </button>
        </div>
      )}

      {/* Hidden Easter Egg Area */}
      <div 
        className="absolute top-0 right-0 w-16 h-16 opacity-0"
        onClick={() => {
          // Secret developer options trigger
          console.log('🥚 Easter egg activated!')
        }}
      />
    </div>
  )
}
