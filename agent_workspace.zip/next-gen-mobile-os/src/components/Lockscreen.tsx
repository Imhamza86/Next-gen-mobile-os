import React, { useState, useEffect, useRef } from 'react'
import { useGesture } from './GestureProvider'
import { useTheme } from './ThemeProvider'

interface LockscreenProps {
  currentTime: Date
  onUnlock: () => void
}

interface Notification {
  id: string
  app: string
  title: string
  content: string
  timestamp: Date
  icon: string
}

export const Lockscreen: React.FC<LockscreenProps> = ({ currentTime, onUnlock }) => {
  const [unlockProgress, setUnlockProgress] = useState(0)
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      app: 'Messages',
      title: 'Welcome to Next-Gen OS',
      content: 'Swipe up to unlock and explore the future of mobile interfaces',
      timestamp: new Date(),
      icon: '💬'
    },
    {
      id: '2',
      app: 'System',
      title: 'Revolutionary UI',
      content: 'Experience fluid animations and intuitive gestures',
      timestamp: new Date(Date.now() - 300000),
      icon: '⚡'
    }
  ])
  
  const lockscreenRef = useRef<HTMLDivElement>(null)
  const { registerGesture, hapticFeedback } = useGesture()
  const { resolvedTheme } = useTheme()

  useEffect(() => {
    if (!lockscreenRef.current) return

    const element = lockscreenRef.current

    // Register swipe up gesture for unlock
    const cleanup = registerGesture(element, {
      type: 'swipe-up',
      threshold: 100,
      callback: () => {
        setUnlockProgress(100)
        hapticFeedback('heavy')
        setTimeout(() => {
          onUnlock()
        }, 300)
      }
    })

    return cleanup
  }, [registerGesture, onUnlock, hapticFeedback])

  const formatTime = (time: Date) => {
    return time.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false 
    })
  }

  const formatDate = (time: Date) => {
    return time.toLocaleDateString([], { 
      weekday: 'long',
      month: 'long', 
      day: 'numeric' 
    })
  }

  return (
    <div 
      ref={lockscreenRef}
      className="relative w-full h-full overflow-hidden"
    >
      {/* Parallax Background */}
      <div className="absolute inset-0 w-full h-full">
        {/* Gradient Background */}
        <div className={`
          absolute inset-0 w-full h-full
          ${resolvedTheme === 'dark' 
            ? 'bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900' 
            : 'bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500'
          }
        `} />
        
        {/* Animated Particles */}
        <div className="absolute inset-0 w-full h-full">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className={`
                absolute w-2 h-2 rounded-full opacity-30
                ${resolvedTheme === 'dark' ? 'bg-white' : 'bg-white/50'}
              `}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animation: `float ${3 + Math.random() * 4}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 2}s`
              }}
            />
          ))}
        </div>

        {/* Glass Overlay */}
        <div className="absolute inset-0 glass-dark opacity-20" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full px-8">
        {/* Time Widget */}
        <div className="text-center mb-8 will-change-transform">
          <div 
            className="text-7xl font-thin text-white mb-2 transition-all duration-300"
            style={{ 
              animation: 'breathe 4s ease-in-out infinite',
              textShadow: '0 0 30px rgba(255, 255, 255, 0.5)'
            }}
          >
            {formatTime(currentTime)}
          </div>
          <div className="text-xl text-white/80 font-light">
            {formatDate(currentTime)}
          </div>
        </div>

        {/* Notifications Stack */}
        <div className="w-full max-w-sm space-y-3 mb-12">
          {notifications.map((notification, index) => (
            <div
              key={notification.id}
              className="glass rounded-2xl p-4 text-white transform transition-all duration-500"
              style={{
                animation: `fade-in-up 0.6s ease-out ${index * 0.1}s both`,
                backdropFilter: 'blur(20px)',
                background: 'rgba(255, 255, 255, 0.1)',
                border: '1px solid rgba(255, 255, 255, 0.2)'
              }}
            >
              <div className="flex items-start space-x-3">
                <div className="text-2xl">{notification.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium opacity-80">
                      {notification.app}
                    </span>
                    <span className="text-xs opacity-60">
                      {notification.timestamp.toLocaleTimeString([], { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </span>
                  </div>
                  <div className="font-medium text-sm mb-1">
                    {notification.title}
                  </div>
                  <div className="text-sm opacity-80 leading-tight">
                    {notification.content}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Unlock Indicator */}
        <div className="flex flex-col items-center space-y-4">
          <div className="relative">
            <div 
              className="w-16 h-16 rounded-full border-2 border-white/30 flex items-center justify-center"
              style={{
                animation: 'pulse-glow 2s ease-in-out infinite'
              }}
            >
              <div className="text-2xl">👆</div>
            </div>
            {unlockProgress > 0 && (
              <div 
                className="absolute inset-0 rounded-full border-2 border-white transition-all duration-300"
                style={{
                  clipPath: `polygon(0 ${100 - unlockProgress}%, 100% ${100 - unlockProgress}%, 100% 100%, 0 100%)`
                }}
              />
            )}
          </div>
          
          <div className="text-white/80 text-sm font-light animate-pulse">
            Swipe up to unlock
          </div>
        </div>
      </div>

      {/* Bottom Gesture Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
        <div 
          className="w-32 h-1 bg-white/50 rounded-full"
          style={{
            animation: 'breathe 3s ease-in-out infinite'
          }}
        />
      </div>
    </div>
  )
}
