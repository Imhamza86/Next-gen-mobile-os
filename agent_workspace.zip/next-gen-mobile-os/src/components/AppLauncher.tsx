import React, { useState, useEffect, useRef } from 'react'
import { useGesture } from './GestureProvider'
import { useTheme } from './ThemeProvider'

interface AppLauncherProps {
  appId: string
  onClose: () => void
}

const APP_CONFIGS = {
  messages: {
    name: 'Messages',
    icon: '💬',
    color: 'from-green-400 to-green-600',
    component: MessagesApp
  },
  camera: {
    name: 'Camera',
    icon: '📷',
    color: 'from-gray-400 to-gray-600',
    component: CameraApp
  },
  calculator: {
    name: 'Calculator',
    icon: '🧮',
    color: 'from-indigo-400 to-purple-600',
    component: CalculatorApp
  },
  weather: {
    name: 'Weather',
    icon: '🌤️',
    color: 'from-blue-300 to-sky-500',
    component: WeatherApp
  },
  music: {
    name: 'Music',
    icon: '🎵',
    color: 'from-pink-400 to-red-500',
    component: MusicApp
  },
  notes: {
    name: 'Notes',
    icon: '📝',
    color: 'from-yellow-300 to-amber-400',
    component: NotesApp
  }
}

// Individual App Components
function MessagesApp() {
  const { resolvedTheme } = useTheme()
  
  const conversations = [
    { id: 1, name: 'Alex Johnson', message: 'This new OS is incredible! 🚀', time: '2m ago', unread: 2 },
    { id: 2, name: 'Design Team', message: 'Sarah: The animations are so smooth!', time: '15m ago', unread: 0 },
    { id: 3, name: 'Mom', message: 'How do you like your new phone?', time: '1h ago', unread: 1 },
    { id: 4, name: 'Tech Conference', message: 'Welcome to the future of mobile interfaces', time: '2h ago', unread: 0 }
  ]

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className={`
        p-4 border-b
        ${resolvedTheme === 'dark' ? 'border-gray-700' : 'border-gray-200'}
      `}>
        <h1 className={`
          text-xl font-semibold
          ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
        `}>
          Messages
        </h1>
      </div>

      {/* Conversations */}
      <div className="flex-1 overflow-y-auto">
        {conversations.map((conversation, index) => (
          <div 
            key={conversation.id}
            className={`
              p-4 border-b flex items-center space-x-3
              ${resolvedTheme === 'dark' ? 'border-gray-700 hover:bg-gray-800' : 'border-gray-100 hover:bg-gray-50'}
              transition-colors duration-200
            `}
            style={{
              animation: `fade-in-up 0.3s ease-out ${index * 0.1}s both`
            }}
          >
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white font-medium">
              {conversation.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className={`
                  font-medium
                  ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
                `}>
                  {conversation.name}
                </span>
                <span className={`
                  text-xs
                  ${resolvedTheme === 'dark' ? 'text-gray-400' : 'text-gray-500'}
                `}>
                  {conversation.time}
                </span>
              </div>
              <div className={`
                text-sm truncate
                ${resolvedTheme === 'dark' ? 'text-gray-300' : 'text-gray-600'}
              `}>
                {conversation.message}
              </div>
            </div>
            {conversation.unread > 0 && (
              <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-medium">
                {conversation.unread}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

function CameraApp() {
  const { resolvedTheme } = useTheme()
  const [isRecording, setIsRecording] = useState(false)

  return (
    <div className="h-full bg-black relative">
      {/* Camera Viewfinder */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-white/50 text-center">
          <div className="text-6xl mb-4">📷</div>
          <div className="text-lg">Camera Preview</div>
          <div className="text-sm mt-2">Tap to capture amazing moments</div>
        </div>
      </div>

      {/* Camera Controls */}
      <div className="absolute bottom-8 left-0 right-0 flex items-center justify-center space-x-8">
        <button className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white text-xl">
          🖼️
        </button>
        
        <button 
          className={`
            w-20 h-20 rounded-full border-4 border-white flex items-center justify-center
            ${isRecording ? 'bg-red-500' : 'bg-transparent'}
            transition-all duration-200
          `}
          onClick={() => setIsRecording(!isRecording)}
        >
          <div className={`
            w-12 h-12 rounded-full bg-white
            ${isRecording ? 'animate-pulse' : ''}
          `} />
        </button>
        
        <button className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-white text-xl">
          🔄
        </button>
      </div>
    </div>
  )
}

function CalculatorApp() {
  const { resolvedTheme } = useTheme()
  const [display, setDisplay] = useState('0')
  const [operation, setOperation] = useState<string | null>(null)
  const [previousValue, setPreviousValue] = useState<number | null>(null)

  const buttons = [
    ['C', '±', '%', '÷'],
    ['7', '8', '9', '×'],
    ['4', '5', '6', '-'],
    ['1', '2', '3', '+'],
    ['0', '', '.', '=']
  ]

  const handleButtonPress = (button: string) => {
    // Calculator logic implementation
    if (button === 'C') {
      setDisplay('0')
      setOperation(null)
      setPreviousValue(null)
    } else if (['+', '-', '×', '÷'].includes(button)) {
      setOperation(button)
      setPreviousValue(parseFloat(display))
      setDisplay('0')
    } else if (button === '=') {
      // Perform calculation
      if (operation && previousValue !== null) {
        let result = 0
        const current = parseFloat(display)
        switch (operation) {
          case '+': result = previousValue + current; break
          case '-': result = previousValue - current; break
          case '×': result = previousValue * current; break
          case '÷': result = previousValue / current; break
        }
        setDisplay(result.toString())
        setOperation(null)
        setPreviousValue(null)
      }
    } else if (button !== '') {
      setDisplay(prev => prev === '0' ? button : prev + button)
    }
  }

  return (
    <div className={`
      h-full flex flex-col
      ${resolvedTheme === 'dark' ? 'bg-black' : 'bg-white'}
    `}>
      {/* Display */}
      <div className="flex-1 flex items-end justify-end p-6">
        <div className={`
          text-5xl font-light text-right
          ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
        `}>
          {display}
        </div>
      </div>

      {/* Buttons */}
      <div className="p-4">
        {buttons.map((row, rowIndex) => (
          <div key={rowIndex} className="flex space-x-3 mb-3">
            {row.map((button, buttonIndex) => (
              <button
                key={buttonIndex}
                className={`
                  flex-1 h-16 rounded-2xl font-medium text-lg
                  ${button === '' ? 'invisible' : ''}
                  ${['C', '±', '%'].includes(button)
                    ? resolvedTheme === 'dark' ? 'bg-gray-600 text-white' : 'bg-gray-300 text-gray-800'
                    : ['+', '-', '×', '÷', '='].includes(button)
                    ? 'bg-orange-500 text-white'
                    : resolvedTheme === 'dark' ? 'bg-gray-800 text-white' : 'bg-gray-100 text-gray-800'
                  }
                  transition-all duration-200 active:scale-95
                `}
                onClick={() => handleButtonPress(button)}
              >
                {button}
              </button>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}

function WeatherApp() {
  const { resolvedTheme } = useTheme()

  const weatherData = {
    current: { temp: 22, condition: 'Partly Cloudy', icon: '🌤️' },
    forecast: [
      { day: 'Today', high: 24, low: 18, icon: '🌤️' },
      { day: 'Tomorrow', high: 26, low: 20, icon: '☀️' },
      { day: 'Wed', high: 23, low: 17, icon: '🌧️' },
      { day: 'Thu', high: 25, low: 19, icon: '☀️' },
      { day: 'Fri', high: 22, low: 16, icon: '⛅' }
    ]
  }

  return (
    <div className={`
      h-full
      ${resolvedTheme === 'dark' 
        ? 'bg-gradient-to-br from-blue-900 to-indigo-900' 
        : 'bg-gradient-to-br from-blue-400 to-sky-500'
      }
    `}>
      <div className="p-6 text-white">
        {/* Current Weather */}
        <div className="text-center mb-8" style={{ animation: 'fade-in-up 0.5s ease-out' }}>
          <div className="text-6xl mb-2">{weatherData.current.icon}</div>
          <div className="text-6xl font-thin mb-2">{weatherData.current.temp}°</div>
          <div className="text-xl opacity-90">{weatherData.current.condition}</div>
          <div className="text-lg opacity-75 mt-2">San Francisco</div>
        </div>

        {/* Forecast */}
        <div className="space-y-3">
          {weatherData.forecast.map((day, index) => (
            <div 
              key={day.day}
              className="glass-dark rounded-2xl p-4 flex items-center justify-between"
              style={{ animation: `fade-in-up 0.5s ease-out ${index * 0.1}s both` }}
            >
              <div className="flex items-center space-x-4">
                <div className="text-2xl">{day.icon}</div>
                <div className="font-medium">{day.day}</div>
              </div>
              <div className="flex items-center space-x-4">
                <span className="opacity-75">{day.low}°</span>
                <span className="font-medium">{day.high}°</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function MusicApp() {
  const { resolvedTheme } = useTheme()
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <div className={`
      h-full flex flex-col
      ${resolvedTheme === 'dark' 
        ? 'bg-gradient-to-br from-purple-900 to-pink-900' 
        : 'bg-gradient-to-br from-purple-400 to-pink-500'
      }
    `}>
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-white">
        {/* Album Art */}
        <div 
          className="w-64 h-64 rounded-3xl bg-gradient-to-br from-blue-400 to-purple-600 mb-8 flex items-center justify-center text-6xl shadow-2xl"
          style={{ animation: 'zoom-in 0.6s ease-out' }}
        >
          🎵
        </div>

        {/* Song Info */}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">Revolutionary Interface</h2>
          <p className="text-lg opacity-90">Next-Gen OS Soundtrack</p>
        </div>

        {/* Progress Bar */}
        <div className="w-full mb-8">
          <div className="w-full h-1 bg-white/30 rounded-full mb-2">
            <div className="w-1/3 h-full bg-white rounded-full" />
          </div>
          <div className="flex justify-between text-sm opacity-75">
            <span>1:23</span>
            <span>3:45</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-8">
          <button className="text-3xl opacity-75">⏮️</button>
          <button 
            className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center text-3xl backdrop-blur-sm"
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? '⏸️' : '▶️'}
          </button>
          <button className="text-3xl opacity-75">⏭️</button>
        </div>
      </div>
    </div>
  )
}

function NotesApp() {
  const { resolvedTheme } = useTheme()
  const [notes, setNotes] = useState([
    { id: 1, title: 'Mobile OS Ideas', preview: 'Revolutionary interface concepts for next-generation smartphones...', date: 'Today' },
    { id: 2, title: 'Design Inspiration', preview: 'Glassmorphism, fluid animations, intuitive gestures...', date: 'Yesterday' },
    { id: 3, title: 'Shopping List', preview: 'Groceries: Apples, Bread, Milk...', date: '2 days ago' }
  ])

  return (
    <div className={`
      h-full
      ${resolvedTheme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}
    `}>
      {/* Header */}
      <div className={`
        p-4 border-b flex items-center justify-between
        ${resolvedTheme === 'dark' ? 'border-gray-700' : 'border-gray-200'}
      `}>
        <h1 className={`
          text-xl font-semibold
          ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
        `}>
          Notes
        </h1>
        <button className={`
          w-8 h-8 rounded-full flex items-center justify-center
          ${resolvedTheme === 'dark' ? 'bg-yellow-600' : 'bg-yellow-500'}
          text-white
        `}>
          +
        </button>
      </div>

      {/* Notes List */}
      <div className="p-4 space-y-3">
        {notes.map((note, index) => (
          <div 
            key={note.id}
            className={`
              p-4 rounded-2xl
              ${resolvedTheme === 'dark' ? 'bg-gray-800' : 'bg-white'}
              shadow-sm
            `}
            style={{ animation: `fade-in-up 0.3s ease-out ${index * 0.1}s both` }}
          >
            <div className="flex items-start justify-between mb-2">
              <h3 className={`
                font-medium
                ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
              `}>
                {note.title}
              </h3>
              <span className={`
                text-sm
                ${resolvedTheme === 'dark' ? 'text-gray-400' : 'text-gray-500'}
              `}>
                {note.date}
              </span>
            </div>
            <p className={`
              text-sm
              ${resolvedTheme === 'dark' ? 'text-gray-300' : 'text-gray-600'}
            `}>
              {note.preview}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}

export const AppLauncher: React.FC<AppLauncherProps> = ({ appId, onClose }) => {
  const [isClosing, setIsClosing] = useState(false)
  const appRef = useRef<HTMLDivElement>(null)
  const { registerGesture, hapticFeedback } = useGesture()
  const { resolvedTheme } = useTheme()

  const appConfig = APP_CONFIGS[appId as keyof typeof APP_CONFIGS]

  useEffect(() => {
    if (!appRef.current) return

    const element = appRef.current

    // Register swipe up for close
    const cleanup = registerGesture(element, {
      type: 'swipe-up-from-bottom',
      threshold: 100,
      callback: () => {
        handleClose()
      }
    })

    return cleanup
  }, [registerGesture])

  const handleClose = () => {
    setIsClosing(true)
    hapticFeedback('light')
    setTimeout(() => {
      onClose()
    }, 300)
  }

  if (!appConfig) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">❓</div>
          <div className="text-lg">App not found</div>
        </div>
      </div>
    )
  }

  const AppComponent = appConfig.component

  return (
    <div 
      ref={appRef}
      className={`
        absolute inset-0 w-full h-full
        ${resolvedTheme === 'dark' ? 'bg-gray-900' : 'bg-white'}
        transition-all duration-300 ease-out
        ${isClosing ? 'scale-95 opacity-0' : 'scale-100 opacity-100'}
      `}
      style={{
        animation: isClosing ? undefined : 'zoom-in 0.4s ease-out'
      }}
    >
      {/* App Content */}
      <AppComponent />

      {/* Home Indicator */}
      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
        <div className={`
          w-32 h-1 rounded-full
          ${resolvedTheme === 'dark' ? 'bg-white/40' : 'bg-black/40'}
        `} />
      </div>
    </div>
  )
}
