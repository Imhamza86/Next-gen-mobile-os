import React, { useState, useEffect, useRef } from 'react'
import { useGesture } from './GestureProvider'
import { useTheme } from './ThemeProvider'

interface ControlCenterProps {
  visible: boolean
  onClose: () => void
}

interface ControlToggle {
  id: string
  label: string
  icon: string
  enabled: boolean
  color: string
}

export const ControlCenter: React.FC<ControlCenterProps> = ({ visible, onClose }) => {
  const [brightness, setBrightness] = useState(75)
  const [volume, setVolume] = useState(60)
  const [toggles, setToggles] = useState<ControlToggle[]>([
    { id: 'wifi', label: 'Wi-Fi', icon: '📶', enabled: true, color: 'from-blue-400 to-blue-600' },
    { id: 'bluetooth', label: 'Bluetooth', icon: '🔵', enabled: false, color: 'from-indigo-400 to-indigo-600' },
    { id: 'airplane', label: 'Airplane Mode', icon: '✈️', enabled: false, color: 'from-orange-400 to-orange-600' },
    { id: 'dnd', label: 'Do Not Disturb', icon: '🌙', enabled: false, color: 'from-purple-400 to-purple-600' },
    { id: 'flashlight', label: 'Flashlight', icon: '🔦', enabled: false, color: 'from-yellow-400 to-yellow-600' },
    { id: 'hotspot', label: 'Personal Hotspot', icon: '📡', enabled: false, color: 'from-green-400 to-green-600' }
  ])

  const controlRef = useRef<HTMLDivElement>(null)
  const { registerGesture, hapticFeedback } = useGesture()
  const { resolvedTheme, toggleTheme, visualMode, setVisualMode } = useTheme()

  useEffect(() => {
    if (!controlRef.current || !visible) return

    const element = controlRef.current

    // Register swipe up to close
    const cleanup = registerGesture(element, {
      type: 'swipe-up',
      threshold: 100,
      callback: () => {
        hapticFeedback('light')
        onClose()
      }
    })

    return cleanup
  }, [registerGesture, visible, onClose, hapticFeedback])

  const toggleControl = (id: string) => {
    setToggles(prev => prev.map(toggle => 
      toggle.id === id ? { ...toggle, enabled: !toggle.enabled } : toggle
    ))
    hapticFeedback('medium')
  }

  const ControlToggleButton: React.FC<{ toggle: ControlToggle; index: number }> = ({ toggle, index }) => (
    <button
      className={`
        glass rounded-2xl p-4 flex flex-col items-center space-y-2
        transition-all duration-300 ease-out
        ${toggle.enabled 
          ? `bg-gradient-to-br ${toggle.color} shadow-lg scale-105` 
          : resolvedTheme === 'dark' ? 'glass-dark' : 'glass'
        }
        hover:scale-110 active:scale-95
      `}
      style={{
        animation: `bounce-in 0.5s ease-out ${index * 0.1}s both`
      }}
      onClick={() => toggleControl(toggle.id)}
    >
      <div className={`
        text-2xl transition-all duration-300
        ${toggle.enabled ? 'animate-pulse' : ''}
      `}>
        {toggle.icon}
      </div>
      <div className={`
        text-xs font-medium text-center
        ${toggle.enabled 
          ? 'text-white' 
          : resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'
        }
      `}>
        {toggle.label}
      </div>
    </button>
  )

  const SliderControl: React.FC<{
    label: string
    icon: string
    value: number
    onChange: (value: number) => void
    color: string
  }> = ({ label, icon, value, onChange, color }) => (
    <div className={`
      glass rounded-2xl p-4
      ${resolvedTheme === 'dark' ? 'glass-dark' : 'glass'}
    `}>
      <div className="flex items-center space-x-3 mb-3">
        <div className="text-2xl">{icon}</div>
        <div className={`
          flex-1 font-medium
          ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
        `}>
          {label}
        </div>
        <div className={`
          text-sm
          ${resolvedTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}
        `}>
          {value}%
        </div>
      </div>
      
      <div className="relative">
        <div className={`
          w-full h-2 rounded-full
          ${resolvedTheme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'}
        `}>
          <div 
            className={`h-full rounded-full bg-gradient-to-r ${color} transition-all duration-300`}
            style={{ width: `${value}%` }}
          />
        </div>
        <input
          type="range"
          min="0"
          max="100"
          value={value}
          onChange={(e) => onChange(parseInt(e.target.value))}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        />
      </div>
    </div>
  )

  if (!visible) return null

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
        style={{ animation: 'fade-in-up 0.3s ease-out' }}
      />

      {/* Control Panel */}
      <div
        ref={controlRef}
        className={`
          absolute top-0 right-0 left-0 max-h-screen overflow-y-auto
          ${resolvedTheme === 'dark' 
            ? 'bg-black/80' 
            : 'bg-white/80'
          }
          backdrop-blur-xl border-b border-white/10
        `}
        style={{ 
          animation: 'slide-down 0.4s ease-out',
          paddingTop: '60px'
        }}
      >
        <div className="px-6 py-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className={`
              text-xl font-semibold
              ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
            `}>
              Control Center
            </h2>
            
            <button
              className={`
                w-8 h-8 rounded-full flex items-center justify-center
                ${resolvedTheme === 'dark' 
                  ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' 
                  : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                }
                transition-colors duration-200
              `}
              onClick={onClose}
            >
              ×
            </button>
          </div>

          {/* Connectivity Controls */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            {toggles.slice(0, 6).map((toggle, index) => (
              <ControlToggleButton key={toggle.id} toggle={toggle} index={index} />
            ))}
          </div>

          {/* Brightness Control */}
          <div className="mb-6">
            <SliderControl
              label="Brightness"
              icon="🔆"
              value={brightness}
              onChange={setBrightness}
              color="from-yellow-400 to-orange-500"
            />
          </div>

          {/* Volume Control */}
          <div className="mb-6">
            <SliderControl
              label="Volume"
              icon="🔊"
              value={volume}
              onChange={setVolume}
              color="from-blue-400 to-indigo-500"
            />
          </div>

          {/* Media Controls */}
          <div className={`
            glass rounded-2xl p-4 mb-6
            ${resolvedTheme === 'dark' ? 'glass-dark' : 'glass'}
          `}>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center text-xl">
                🎵
              </div>
              <div className="flex-1">
                <div className={`
                  font-medium
                  ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
                `}>
                  Revolutionary Interface
                </div>
                <div className={`
                  text-sm
                  ${resolvedTheme === 'dark' ? 'text-gray-400' : 'text-gray-600'}
                `}>
                  Next-Gen OS Soundtrack
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-center space-x-6">
              {['⏮️', '⏯️', '⏭️'].map((icon, index) => (
                <button
                  key={index}
                  className={`
                    w-12 h-12 rounded-full flex items-center justify-center text-xl
                    ${resolvedTheme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'}
                    transition-colors duration-200
                  `}
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>

          {/* Theme Controls */}
          <div className={`
            glass rounded-2xl p-4 mb-6
            ${resolvedTheme === 'dark' ? 'glass-dark' : 'glass'}
          `}>
            <div className={`
              font-medium mb-3
              ${resolvedTheme === 'dark' ? 'text-white' : 'text-gray-800'}
            `}>
              Appearance
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <button
                className={`
                  p-3 rounded-xl flex items-center justify-center space-x-2
                  ${resolvedTheme === 'dark' 
                    ? 'bg-gradient-to-br from-gray-600 to-gray-800 text-white' 
                    : 'bg-gray-200 text-gray-800'
                  }
                  transition-all duration-200 hover:scale-105
                `}
                onClick={toggleTheme}
              >
                <span>{resolvedTheme === 'dark' ? '🌙' : '☀️'}</span>
                <span className="text-sm font-medium">
                  {resolvedTheme === 'dark' ? 'Dark' : 'Light'}
                </span>
              </button>
              
              <button
                className={`
                  p-3 rounded-xl flex items-center justify-center space-x-2
                  ${visualMode === 'glassmorphism' 
                    ? 'bg-gradient-to-br from-blue-400 to-purple-500 text-white' 
                    : resolvedTheme === 'dark' ? 'bg-gray-700 text-white' : 'bg-gray-200 text-gray-800'
                  }
                  transition-all duration-200 hover:scale-105
                `}
                onClick={() => setVisualMode(visualMode === 'glassmorphism' ? 'normal' : 'glassmorphism')}
              >
                <span>✨</span>
                <span className="text-sm font-medium">Glass</span>
              </button>
            </div>
          </div>

          {/* Pull Indicator */}
          <div className="flex justify-center pb-4">
            <div className={`
              w-8 h-1 rounded-full
              ${resolvedTheme === 'dark' ? 'bg-white/40' : 'bg-black/40'}
            `} />
          </div>
        </div>
      </div>
    </div>
  )
}
