import React, { createContext, useContext, useCallback, useRef } from 'react'

export type GestureType = 
  | 'swipe-up' 
  | 'swipe-down' 
  | 'swipe-left' 
  | 'swipe-right'
  | 'swipe-up-from-bottom'
  | 'swipe-down-from-top'
  | 'swipe-down-from-top-right'
  | 'tap'
  | 'double-tap'
  | 'long-press'
  | 'pinch'

interface GestureConfig {
  type: GestureType
  callback: (event?: any) => void
  threshold?: number
  duration?: number
}

interface GestureContextType {
  registerGesture: (element: HTMLElement, config: GestureConfig) => () => void
  hapticFeedback: (type: 'light' | 'medium' | 'heavy') => void
}

const GestureContext = createContext<GestureContextType | undefined>(undefined)

export const useGesture = () => {
  const context = useContext(GestureContext)
  if (!context) {
    throw new Error('useGesture must be used within a GestureProvider')
  }
  return context
}

export const GestureProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const gestureState = useRef({
    startX: 0,
    startY: 0,
    startTime: 0,
    isTracking: false,
    tapCount: 0,
    lastTapTime: 0
  })

  const hapticFeedback = useCallback((type: 'light' | 'medium' | 'heavy') => {
    // Simulate haptic feedback with visual pulse
    if (navigator.vibrate) {
      const patterns = {
        light: [10],
        medium: [50],
        heavy: [100]
      }
      navigator.vibrate(patterns[type])
    }
    
    // Add visual haptic feedback
    document.body.style.transform = 'scale(1.001)'
    setTimeout(() => {
      document.body.style.transform = 'scale(1)'
    }, 50)
  }, [])

  const registerGesture = useCallback((element: HTMLElement, config: GestureConfig) => {
    const { type, callback, threshold = 50, duration = 500 } = config
    
    const handleTouchStart = (e: TouchEvent) => {
      const touch = e.touches[0]
      gestureState.current = {
        startX: touch.clientX,
        startY: touch.clientY,
        startTime: Date.now(),
        isTracking: true,
        tapCount: gestureState.current.tapCount,
        lastTapTime: gestureState.current.lastTapTime
      }
    }

    const handleTouchMove = (e: TouchEvent) => {
      if (!gestureState.current.isTracking) return
      
      const touch = e.touches[0]
      const deltaX = touch.clientX - gestureState.current.startX
      const deltaY = touch.clientY - gestureState.current.startY
      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY)
      
      // Prevent scrolling during gesture recognition
      if (distance > 10) {
        e.preventDefault()
      }
    }

    const handleTouchEnd = (e: TouchEvent) => {
      if (!gestureState.current.isTracking) return
      
      const touch = e.changedTouches[0]
      const deltaX = touch.clientX - gestureState.current.startX
      const deltaY = touch.clientY - gestureState.current.startY
      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY)
      const timeDelta = Date.now() - gestureState.current.startTime
      
      gestureState.current.isTracking = false

      // Determine gesture type
      if (distance < 10 && timeDelta < 300) {
        // Tap gesture
        const now = Date.now()
        if (now - gestureState.current.lastTapTime < 300) {
          gestureState.current.tapCount++
        } else {
          gestureState.current.tapCount = 1
        }
        gestureState.current.lastTapTime = now

        if (type === 'tap' && gestureState.current.tapCount === 1) {
          setTimeout(() => {
            if (gestureState.current.tapCount === 1) {
              hapticFeedback('light')
              callback()
            }
          }, 300)
        } else if (type === 'double-tap' && gestureState.current.tapCount === 2) {
          hapticFeedback('medium')
          callback()
          gestureState.current.tapCount = 0
        }
      } else if (distance > threshold) {
        // Swipe gestures
        const angle = Math.atan2(deltaY, deltaX) * 180 / Math.PI
        const absAngle = Math.abs(angle)
        const isHorizontal = absAngle < 45 || absAngle > 135
        const isVertical = absAngle >= 45 && absAngle <= 135

        // Check for edge-based gestures
        const startY = gestureState.current.startY
        const startX = gestureState.current.startX
        const screenHeight = window.innerHeight
        const screenWidth = window.innerWidth
        const edgeThreshold = 50

        if (type === 'swipe-up-from-bottom' && 
            startY > screenHeight - edgeThreshold && 
            deltaY < -threshold) {
          hapticFeedback('medium')
          callback()
        } else if (type === 'swipe-down-from-top' && 
                   startY < edgeThreshold && 
                   deltaY > threshold &&
                   startX < screenWidth * 0.7) {
          hapticFeedback('medium')
          callback()
        } else if (type === 'swipe-down-from-top-right' && 
                   startY < edgeThreshold && 
                   startX > screenWidth * 0.7 &&
                   deltaY > threshold) {
          hapticFeedback('medium')
          callback()
        } else if (isVertical) {
          if (deltaY < -threshold && type === 'swipe-up') {
            hapticFeedback('light')
            callback()
          } else if (deltaY > threshold && type === 'swipe-down') {
            hapticFeedback('light')
            callback()
          }
        } else if (isHorizontal) {
          if (deltaX < -threshold && type === 'swipe-left') {
            hapticFeedback('light')
            callback()
          } else if (deltaX > threshold && type === 'swipe-right') {
            hapticFeedback('light')
            callback()
          }
        }
      }
    }

    const handleLongPress = () => {
      if (type === 'long-press') {
        hapticFeedback('heavy')
        callback()
      }
    }

    let longPressTimer: NodeJS.Timeout

    const startLongPress = () => {
      longPressTimer = setTimeout(handleLongPress, duration)
    }

    const cancelLongPress = () => {
      clearTimeout(longPressTimer)
    }

    // Add event listeners
    element.addEventListener('touchstart', handleTouchStart, { passive: false })
    element.addEventListener('touchmove', handleTouchMove, { passive: false })
    element.addEventListener('touchend', handleTouchEnd, { passive: false })
    
    if (type === 'long-press') {
      element.addEventListener('touchstart', startLongPress)
      element.addEventListener('touchend', cancelLongPress)
      element.addEventListener('touchmove', cancelLongPress)
    }

    // Return cleanup function
    return () => {
      element.removeEventListener('touchstart', handleTouchStart)
      element.removeEventListener('touchmove', handleTouchMove)
      element.removeEventListener('touchend', handleTouchEnd)
      
      if (type === 'long-press') {
        element.removeEventListener('touchstart', startLongPress)
        element.removeEventListener('touchend', cancelLongPress)
        element.removeEventListener('touchmove', cancelLongPress)
      }
      
      clearTimeout(longPressTimer)
    }
  }, [hapticFeedback])

  const value: GestureContextType = {
    registerGesture,
    hapticFeedback
  }

  return (
    <GestureContext.Provider value={value}>
      {children}
    </GestureContext.Provider>
  )
}
