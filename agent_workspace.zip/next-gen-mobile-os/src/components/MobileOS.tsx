import React, { useState, useEffect, useRef } from 'react'
import { Lockscreen } from './Lockscreen'
import { Homescreen } from './Homescreen'
import { NotificationCenter } from './NotificationCenter'
import { AppLauncher } from './AppLauncher'
import { ControlCenter } from './ControlCenter'
import { useGesture } from './GestureProvider'
import { useTheme } from './ThemeProvider'

export type OSState = 'locked' | 'homescreen' | 'app' | 'notifications' | 'control-center'

export const MobileOS: React.FC = () => {
  const [osState, setOSState] = useState<OSState>('locked')
  const [currentApp, setCurrentApp] = useState<string | null>(null)
  const [notificationVisible, setNotificationVisible] = useState(false)
  const [controlCenterVisible, setControlCenterVisible] = useState(false)
  const [currentTime, setCurrentTime] = useState(new Date())
  
  const osRef = useRef<HTMLDivElement>(null)
  const { registerGesture } = useGesture()
  const { theme } = useTheme()

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  // Register global gestures
  useEffect(() => {
    if (!osRef.current) return

    const element = osRef.current

    // Swipe up from bottom - go home
    registerGesture(element, {
      type: 'swipe-up-from-bottom',
      callback: () => {
        if (osState === 'app') {
          setOSState('homescreen')
          setCurrentApp(null)
        }
      }
    })

    // Swipe down from top - notifications
    registerGesture(element, {
      type: 'swipe-down-from-top',
      callback: () => {
        if (osState === 'homescreen' || osState === 'app') {
          setNotificationVisible(true)
        }
      }
    })

    // Swipe down from top-right - control center
    registerGesture(element, {
      type: 'swipe-down-from-top-right',
      callback: () => {
        if (osState === 'homescreen' || osState === 'app') {
          setControlCenterVisible(true)
        }
      }
    })

  }, [osState, registerGesture])

  const unlockDevice = () => {
    setOSState('homescreen')
  }

  const launchApp = (appId: string) => {
    setCurrentApp(appId)
    setOSState('app')
  }

  const closeNotifications = () => {
    setNotificationVisible(false)
  }

  const closeControlCenter = () => {
    setControlCenterVisible(false)
  }

  return (
    <div 
      ref={osRef}
      className={`
        relative w-full h-full overflow-hidden 
        ${theme === 'dark' ? 'bg-black' : 'bg-white'}
        transition-all duration-300 ease-out
      `}
    >
      {/* Status Bar */}
      <div className="absolute top-0 left-0 right-0 z-50 h-12 flex items-center justify-between px-6 text-white mix-blend-difference">
        <div className="text-sm font-medium">
          {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
        <div className="flex items-center space-x-1">
          <div className="w-6 h-3 border border-white rounded-sm">
            <div className="w-4 h-1 bg-white rounded-sm m-0.5"></div>
          </div>
        </div>
      </div>

      {/* Main OS Interface */}
      <div className="relative w-full h-full">
        {/* Lockscreen */}
        {osState === 'locked' && (
          <Lockscreen 
            currentTime={currentTime}
            onUnlock={unlockDevice}
          />
        )}

        {/* Homescreen */}
        {osState === 'homescreen' && (
          <Homescreen 
            onAppLaunch={launchApp}
          />
        )}

        {/* App Launcher */}
        {osState === 'app' && currentApp && (
          <AppLauncher 
            appId={currentApp}
            onClose={() => setOSState('homescreen')}
          />
        )}

        {/* Notification Center */}
        {notificationVisible && (
          <NotificationCenter 
            onClose={closeNotifications}
            visible={notificationVisible}
          />
        )}

        {/* Control Center */}
        {controlCenterVisible && (
          <ControlCenter 
            onClose={closeControlCenter}
            visible={controlCenterVisible}
          />
        )}
      </div>

      {/* Easter Eggs and Hidden Features */}
      <div className="absolute bottom-0 left-0 w-full h-20 pointer-events-none">
        {/* Hidden gesture area for secrets */}
      </div>
    </div>
  )
}
