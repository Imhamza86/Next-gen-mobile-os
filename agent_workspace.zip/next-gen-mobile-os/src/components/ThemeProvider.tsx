import React, { createContext, useContext, useState, useEffect } from 'react'

export type Theme = 'light' | 'dark' | 'auto'
export type VisualMode = 'normal' | 'nothing' | 'glassmorphism' | 'minimal'

interface ThemeContextType {
  theme: Theme
  resolvedTheme: 'light' | 'dark'
  visualMode: VisualMode
  setTheme: (theme: Theme) => void
  setVisualMode: (mode: VisualMode) => void
  toggleTheme: () => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export const useTheme = () => {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('mobile-os-theme')
    return (saved as Theme) || 'dark'
  })
  
  const [visualMode, setVisualMode] = useState<VisualMode>(() => {
    const saved = localStorage.getItem('mobile-os-visual-mode')
    return (saved as VisualMode) || 'normal'
  })

  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('dark')

  useEffect(() => {
    localStorage.setItem('mobile-os-theme', theme)
  }, [theme])

  useEffect(() => {
    localStorage.setItem('mobile-os-visual-mode', visualMode)
  }, [visualMode])

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    
    const updateResolvedTheme = () => {
      if (theme === 'auto') {
        setResolvedTheme(mediaQuery.matches ? 'dark' : 'light')
      } else {
        setResolvedTheme(theme)
      }
    }

    updateResolvedTheme()
    mediaQuery.addEventListener('change', updateResolvedTheme)
    
    return () => mediaQuery.removeEventListener('change', updateResolvedTheme)
  }, [theme])

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark')
  }

  const value: ThemeContextType = {
    theme,
    resolvedTheme,
    visualMode,
    setTheme,
    setVisualMode,
    toggleTheme
  }

  return (
    <ThemeContext.Provider value={value}>
      <div className={`${resolvedTheme} ${visualMode}`}>
        {children}
      </div>
    </ThemeContext.Provider>
  )
}
